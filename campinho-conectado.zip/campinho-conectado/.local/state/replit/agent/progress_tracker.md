[x] 1. Install the required packages
[x] 2. Set up Replit full-stack template structure (schema, storage, routes, server)
[x] 3. Migrate authentication from Supabase to JWT-based auth
[x] 4. Push database schema using `npm run db:push`  
[x] 5. Restructure frontend to use wouter and new auth system
[x] 6. Fix server startup - changed from `tsx watch` to `tsx` to prevent restart loops
[x] 7. Fix security issues - password hashing and JWT_SECRET
[x] 8. Fix double hashing bug in storage layer
[x] 9. Fix BottomNav to use wouter instead of react-router-dom
[x] 10. Application fully functional with authentication working

## Status atual:
✅ Servidor rodando estável em 0.0.0.0:5000
✅ Todas as páginas criadas (Home, Jogos, Time, Perfil, Auth)
✅ Navegação móvel funcionando (BottomNav)
✅ Autenticação JWT completa e funcional
✅ Senhas hasheadas com bcrypt (10 rounds)
✅ PostgreSQL configurado com Drizzle ORM
✅ Frontend em português (Campinho Conectado)
✅ Tema verde/dourado (cores de futebol)